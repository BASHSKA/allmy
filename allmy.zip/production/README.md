# ENGINE V 0.1.1
Created by BASHSKA
# 1. Directories
	\-BACKEND        
		-------\MODULES
		-------engine.php
		-------config.php
	\-FRONTEND
		-------\FULLPAGE
		-------\IMG
		-------\SCRIPTS
		-------\STYLES
		-------\TPL
		-------index.php
		
## 1.1 Structure 
### -BACKEND
Here 
        
# 2. Using
    
# 3. Structure of fullpage.tpl
    <!doctype html>
    <html>
    <head>
        $HEAD_LINKS$
        <title></title>
    </head>
    <body>
        {{YOUR BLOCKS}}
    </body>
    </html>